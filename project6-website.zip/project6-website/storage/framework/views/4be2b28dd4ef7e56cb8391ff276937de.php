<?php $__env->startSection('content'); ?>

        <div class="relative">
            <div class="bg-cover bg-center h-96" style="background-image: url('<?php echo e(asset('images/intratuin.png')); ?>');">
            </div>
            <div class="absolute top-10 left-0 flex flex-col justify-top h-max w-max bg-white bg-opacity-50 py-8 px-8">
                <div class="flex text-black mb-4">
                    <p class="pr-4">Nuenen <br> 2587 WD <br> Tuinstraat 167</p>
                    <p class="pr-4">Zwanenburg <br> 1161 AM <br> Kruiswaal 16</p>
                    <p>Soesterberg <br> 3769 DH <br> Kampweg 47</p>
                </div>
                <div class="center">
                    <a href="/contact"
                        class="bg-green-700 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-r-lg rounded-l-lg 
                        border border-gray-200 w-32 text-center">Contact</a>
                </div>
            </div>
        </div>
        <h1 class="text-2xl font-bold text-center py-5">Producten</h1>

        <div class="w-full px-4">
            <div class="grid grid-cols-5 gap-5">
                <?php
                    $alert = session('alert');
                ?>

                <?php echo $__env->make('_alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php $__currentLoopData = $products->random(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="relative">
                        <a href="<?php echo e(route('product.show', ['id' => $product['id']])); ?>" class="block overflow-hidden h-max">
                            <img src="<?php echo e($product['image']); ?>" alt="<?php echo e($product['name']); ?>"
                                class="object-cover w-full h-full">
                        </a>
                        <div class="p-4 bg-white shadow-lg rounded-lg flex flex-col justify-between">
                            <div class="mb-2">
                                <h2 class="text-lg font-bold mb-2 overflow-hidden whitespace-nowrap overflow-ellipsis"
                                ><?php echo e($product['name']); ?></h2>
                            </div>
                            <div class="flex gap-4 items-center">
                                <div class="flex gap-4 justify-between items-start">
                                    <div class="flex flex-col items-center">
                                        <label for="price" class="font-bold">Prijs:</label>
                                        <p class="text-black">&euro;<?php echo e($product['price']); ?></p>
                                    </div>
                                    <form method="POST" action="<?php echo e(route('cart.add')); ?>"
                                        class="flex gap-4 items-center justify-evenly">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="product_id" value="<?php echo e($product['id']); ?>">
                                        <div class="flex flex-col items-center">
                                            <label for="quantity" class="font-bold">Aantal:</label>
                                            <input type="number" name="quantity" value="1" min="1"
                                                max="10" class="w-10 outline-none">
                                        </div>
                                        <button type="submit"
                                            class="bg-green-700 hover:bg-green-600 text-white font-bold py-2 px-4 rounded">
                                            Voeg toe</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="flex justify-center items-center py-5">
            <a href="/producten"
                class="bg-green-700 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-r-lg rounded-l-lg 
                        border border-green-800 w-32 text-center">Meer Zien</a>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\guido\OneDrive\Documenten\School Projecten\Leerjaar 3\Project-6\project6-website\resources\views/home.blade.php ENDPATH**/ ?>