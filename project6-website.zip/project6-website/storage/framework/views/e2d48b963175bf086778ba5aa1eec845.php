

<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 class="text-2xl font-bold mb-4">Medewerkers</h1>
        <!-- Search Bar -->
        <form action="<?php echo e(route('employees.index')); ?>" method="GET" class="mb-4">
            <div class="flex justify-end">
                <input type="text" name="search" value="<?php echo e($search); ?>"
                    class="shadow appearance-none border rounded-l w-2/4 py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Zoek...">
                <button type="submit"
                    class="bg-green-700 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-r ml-2">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </form>

        <?php if(count($employees) > 0): ?>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Naam
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Email
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Medewerker Nummer
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Rol
                        </th>
                        <th class="relative px-6 py-3">
                            <span class="sr-only">Bewerk</span>
                        </th>
                        <th class="relative px-6 py-3">
                            <span class="sr-only">Verwijder</span>
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isCurrentUser = $employee->id === auth()->id();
                        ?>

                        <tr class="<?php echo e($isCurrentUser ? 'bg-gray-200' : ''); ?>">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php echo e($employee->name); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php echo e($employee->email); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php echo e($employee->employee_number); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php echo e($employee->role); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <a href="<?php echo e(route('employees.edit', $employee)); ?>"
                                    class="text-indigo-600 hover:text-indigo-900">Bewerk</a>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <form action="<?php echo e(route('employees.destroy', $employee)); ?>" method="POST"
                                    onsubmit="return confirm('Are you sure you want to delete this employee?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:text-red-900">Verwijder</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="mt-4">
                <a href="<?php echo e(route('employees.create')); ?>"
                    class="bg-green-700 hover:bg-green-600 text-white font-bold py-2 px-4 rounded">Medewerker toevoegen</a>
            </div>
        <?php else: ?>
            <p>Geen medewerkers gevonden</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\guido\OneDrive\Documenten\School Projecten\Leerjaar 3\Project-6\project6-website\resources\views/employees/index.blade.php ENDPATH**/ ?>