<?php if($alert): ?>
    <div class="fixed top-0 left-0 right-0 flex justify-center mt-4">
        <?php if($alert['type'] === 'error'): ?>
            <div class="bg-red-500 text-white font-bold py-2 px-4 rounded border-2 border-red-700 flex flex-col items-center">
                <span><?php echo e($alert['message']); ?></span>
                <?php if(!empty($insufficientStockProducts)): ?>
                    <div class="mt-4">
                        <p class="text-lg font-bold">Onvoldoende voorraad voor de volgende product(en):</p>
                        <ul>
                            <?php $__currentLoopData = $insufficientStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($product); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <button type="button" class="text-white mt-4 font-bold block" onclick="this.parentNode.parentNode.remove()">
                    &times;
                </button>
            </div>
        <?php else: ?>
            <div class="bg-green-500 text-white font-bold py-2 px-4 rounded border-2 border-green-700 flex items-center justify-between">
                <span><?php echo e($alert['message']); ?></span>
                <button type="button" class="text-white ml-2 font-bold" onclick="this.parentNode.parentNode.remove()">
                    &times;
                </button>
            </div>
        <?php endif; ?>
    </div>

    <?php if($alert['autoClose']): ?>
        <script>
            setTimeout(function() {
                document.querySelector('.fixed.top-0.left-0.right-0').remove();
            }, 3000); // Adjust the duration (in milliseconds) as needed
        </script>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\Users\guido\OneDrive\Documenten\School Projecten\Leerjaar 3\Project-6\project6-website\resources\views/_alert.blade.php ENDPATH**/ ?>