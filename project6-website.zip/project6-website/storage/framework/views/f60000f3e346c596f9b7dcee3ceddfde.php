<?php $__env->startSection('content'); ?>
        <div class="container mx-auto my-8">
            <h1 class="text-2xl font-bold mb-4">Producten</h1>
            <div class="flex flex-wrap">
                <div class="w-full lg:w-1/4 px-4">
                    <h2 class="text-lg font-bold mb-2">Filters</h2>

                    

                    <form method="GET" action="<?php echo e(route('product.search')); ?>" class="mb-4 flex flex-col">
                        <label class="text-gray-700 font-bold mb-2" for="search">Zoeken</label>
                        <div class="relative flex">
                            <input type="text" name="search" id="search"
                                class="shadow appearance-none border rounded-l w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                placeholder="Zoek...">
                            <button type="submit"
                                class="bg-green-700 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-r ml-2">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>


                    

                    <form action="<?php echo e(route('products.filter')); ?>" method="GET">
                        <div class="mb-4">
                            <label class="block text-gray-700 font-bold mb-2" for="price">Prijs</label>
                            <select name="price" id="price"
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                                <option value="">Alle prijzen</option>
                                <option value="0-5" <?php echo e(request('price') == '0-5' ? 'selected' : ''); ?>>€0 - €5</option>
                                <option value="5-10" <?php echo e(request('price') == '5-10' ? 'selected' : ''); ?>>€5 - €10</option>
                                <option value="10-15" <?php echo e(request('price') == '10-15' ? 'selected' : ''); ?>>€10 - €15
                                </option>
                                <option value="15+" <?php echo e(request('price') == '15+' ? 'selected' : ''); ?>>€15+</option>
                            </select>
                        </div>

                        <div class="mb-4">
                            <label class="block text-gray-700 font-bold mb-2" for="sort">Sorteren op prijs</label>
                            <select name="sort" id="sort"
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                                <option value="">Normaal</option>
                                <option value="low-to-high" <?php echo e(request('sort') == 'low-to-high' ? 'selected' : ''); ?>>Prijs:
                                    Laag naar Hoog</option>
                                <option value="high-to-low" <?php echo e(request('sort') == 'high-to-low' ? 'selected' : ''); ?>>Prijs:
                                    Hoog naar Laag</option>
                            </select>
                        </div>

                        <button type="submit"
                            class="bg-green-700 hover:bg-green-600 text-white font-bold py-2 px-4 rounded">Filter</button>
                    </form>
                </div>

                

                <div class="w-full lg:w-3/4 px-4">
                    <div class="grid grid-cols-4 gap-4">

                        <?php
                            $alert = session('alert');
                        ?>

                        <?php echo $__env->make('_alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="relative">
                                <a href="<?php echo e(route('product.show', ['id' => $product->id])); ?>"
                                    class="block overflow-hidden h-max">
                                    <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>"
                                        class="object-cover w-full h-full" data-src="<?php echo e($product->image); ?>">
                                </a>
                                <div class="p-4 bg-white shadow-lg rounded-lg flex flex-col justify-between">
                                    <div class="mb-2">
                                        <h2
                                            class="text-lg font-bold mb-2 overflow-hidden whitespace-nowrap overflow-ellipsis">
                                            <?php echo e($product->name); ?></h2>
                                    </div>
                                    <div class="flex gap-4 justify-between items-start">
                                        <div class="flex flex-col items-center">
                                            <label for="price" class="font-bold">Prijs:</label>
                                            <p class="text-black">&euro;<?php echo e($product->price); ?></p>
                                        </div>
                                        <form method="POST" action="<?php echo e(route('cart.add')); ?>"
                                            class="flex gap-4 items-center justify-evenly">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                            <div class="flex flex-col items-center">
                                                <label for="quantity" class="font-bold">Aantal:</label>
                                                <input type="number" name="quantity" value="1" min="1"
                                                    class="w-10 outline-none">
                                            </div>
                                            <button type="submit"
                                                class="bg-green-700 hover:bg-green-600 text-white font-bold py-2 px-4 rounded">Voeg
                                                toe</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="pagination flex justify-center items-center mt-8">
                        <?php echo e($products->appends(['price' => request('price')])->links('vendor.pagination.tailwind')); ?>

                    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\guido\OneDrive\Documenten\School Projecten\Leerjaar 3\Project-6\project6-website\resources\views/product/products.blade.php ENDPATH**/ ?>